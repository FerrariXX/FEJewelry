//
//  JELeftSidePanelVC.h
//  Jewelry
//
//  Created by xxx on 14-4-16.
//  Copyright (c) 2014年 FE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JELeftSidePanelVC : UITableViewController

@end
