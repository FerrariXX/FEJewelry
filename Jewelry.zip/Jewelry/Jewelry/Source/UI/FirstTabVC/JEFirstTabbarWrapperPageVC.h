//
//  JEFirstTabbarWrapperPageVC.h
//  Jewelry
//
//  Created by xxx on 14-5-18.
//  Copyright (c) 2014年 FE. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FEScrollPageViewController.h"

@interface JEFirstTabbarWrapperPageVC : FEScrollPageViewController

@end
