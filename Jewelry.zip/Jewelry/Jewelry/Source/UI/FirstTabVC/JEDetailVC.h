//
//  JEDetailVC.h
//  Jewelry
//
//  Created by xxx on 14-5-4.
//  Copyright (c) 2014年 FE. All rights reserved.
//

#import <UIKit/UIKit.h>

@class JEDetailModel;

@interface JEDetailVC : UIViewController
@property(nonatomic, strong)JEDetailModel *model;

@end
